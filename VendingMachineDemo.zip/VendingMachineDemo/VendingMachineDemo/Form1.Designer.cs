﻿namespace VendingMachineDemo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            grp1 = new GroupBox();
            grp2 = new GroupBox();
            btStart = new Button();
            pictureBox1 = new PictureBox();
            grp1.SuspendLayout();
            grp2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // grp1
            // 
            grp1.Controls.Add(pictureBox1);
            grp1.Location = new Point(18, 18);
            grp1.Name = "grp1";
            grp1.Size = new Size(571, 407);
            grp1.TabIndex = 0;
            grp1.TabStop = false;
            grp1.Text = "Display Screen";
            // 
            // grp2
            // 
            grp2.Controls.Add(btStart);
            grp2.Location = new Point(595, 18);
            grp2.Name = "grp2";
            grp2.Size = new Size(280, 407);
            grp2.TabIndex = 1;
            grp2.TabStop = false;
            grp2.Text = "User Box";
            // 
            // btStart
            // 
            btStart.Location = new Point(96, 184);
            btStart.Name = "btStart";
            btStart.Size = new Size(94, 27);
            btStart.TabIndex = 0;
            btStart.Text = "Start";
            btStart.UseVisualStyleBackColor = true;
            btStart.Click += btStart_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(6, 22);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(557, 376);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(887, 450);
            Controls.Add(grp2);
            Controls.Add(grp1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Ticket Vendor Machine";
            Load += Form1_Load;
            grp1.ResumeLayout(false);
            grp2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grp1;
        private GroupBox grp2;
        private Button btStart;
        private PictureBox pictureBox1;
    }
}