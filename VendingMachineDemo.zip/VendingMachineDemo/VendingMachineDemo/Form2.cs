﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace VendingMachineDemo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection cn;
        SqlDataAdapter data;
        DataTable tb;
        SqlCommand cm;
        int dk = 0;

        private void Form2_Load(object sender, EventArgs e)
        {
            string s = "initial catalog = TicketVendorMachine; data source = ACERLT; integrated security = true";
            cn = new SqlConnection(s);
            cn.Open();

            cbSC.Enabled = false;
            dtp.Enabled = false;
            cbTime.Enabled = false;
            numBox.Enabled = false;
        }

        private void grp2_Enter(object sender, EventArgs e)
        {

        }

        private void cbArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbArea.Text == "Quan 8")
            {
                cbSC.Enabled = true;
                cbSC.Items.Add("15 Hung Phu");
                cbSC.Items.Add("7 Pham The Hien");
                cbSC.Items.Add("250 Ben Ba Dinh)");
            }
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {

        }

        private void cbSC_SelectedIndexChanged(object sender, EventArgs e)
        {
            numBox.Enabled = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void numBox_ValueChanged(object sender, EventArgs e)
        {
            dtp.Enabled = true;
            cbTime.Enabled = true;
        }
    }
}
