﻿namespace VendingMachineDemo
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            grp2 = new GroupBox();
            btMP = new Button();
            btCD = new Button();
            label5 = new Label();
            numBox = new NumericUpDown();
            dtp = new DateTimePicker();
            cbTime = new ComboBox();
            cbSC = new ComboBox();
            cbArea = new ComboBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            grp1 = new GroupBox();
            pb1 = new PictureBox();
            grp2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numBox).BeginInit();
            grp1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pb1).BeginInit();
            SuspendLayout();
            // 
            // grp2
            // 
            grp2.Controls.Add(btMP);
            grp2.Controls.Add(btCD);
            grp2.Controls.Add(label5);
            grp2.Controls.Add(numBox);
            grp2.Controls.Add(dtp);
            grp2.Controls.Add(cbTime);
            grp2.Controls.Add(cbSC);
            grp2.Controls.Add(cbArea);
            grp2.Controls.Add(label4);
            grp2.Controls.Add(label3);
            grp2.Controls.Add(label2);
            grp2.Controls.Add(label1);
            grp2.Location = new Point(589, 12);
            grp2.Name = "grp2";
            grp2.Size = new Size(280, 407);
            grp2.TabIndex = 3;
            grp2.TabStop = false;
            grp2.Text = "User Box";
            // 
            // btMP
            // 
            btMP.Location = new Point(13, 347);
            btMP.Name = "btMP";
            btMP.Size = new Size(250, 29);
            btMP.TabIndex = 11;
            btMP.Text = "Mobile Payment";
            btMP.UseVisualStyleBackColor = true;
            // 
            // btCD
            // 
            btCD.Location = new Point(13, 312);
            btCD.Name = "btCD";
            btCD.Size = new Size(250, 29);
            btCD.TabIndex = 10;
            btCD.Text = "Credit Card";
            btCD.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 290);
            label5.Name = "label5";
            label5.Size = new Size(99, 15);
            label5.TabIndex = 9;
            label5.Text = "Payment Method";
            // 
            // numBox
            // 
            numBox.Location = new Point(11, 127);
            numBox.Name = "numBox";
            numBox.Size = new Size(252, 23);
            numBox.TabIndex = 8;
            numBox.ValueChanged += numBox_ValueChanged;
            // 
            // dtp
            // 
            dtp.Location = new Point(13, 167);
            dtp.Name = "dtp";
            dtp.Size = new Size(117, 23);
            dtp.TabIndex = 7;
            dtp.ValueChanged += dtp_ValueChanged;
            // 
            // cbTime
            // 
            cbTime.FormattingEnabled = true;
            cbTime.Items.AddRange(new object[] { "9 AM", "12 AM", "13 PM", "18 PM", "19 PM" });
            cbTime.Location = new Point(136, 167);
            cbTime.Name = "cbTime";
            cbTime.Size = new Size(127, 23);
            cbTime.TabIndex = 6;
            // 
            // cbSC
            // 
            cbSC.FormattingEnabled = true;
            cbSC.Location = new Point(11, 83);
            cbSC.Name = "cbSC";
            cbSC.Size = new Size(252, 23);
            cbSC.TabIndex = 5;
            cbSC.SelectedIndexChanged += cbSC_SelectedIndexChanged;
            // 
            // cbArea
            // 
            cbArea.FormattingEnabled = true;
            cbArea.Items.AddRange(new object[] { "Quan 8" });
            cbArea.Location = new Point(11, 39);
            cbArea.Name = "cbArea";
            cbArea.Size = new Size(252, 23);
            cbArea.TabIndex = 4;
            cbArea.SelectedIndexChanged += cbArea_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 65);
            label4.Name = "label4";
            label4.Size = new Size(140, 15);
            label4.TabIndex = 3;
            label4.Text = "Choose Specific Location";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 109);
            label3.Name = "label3";
            label3.Size = new Size(144, 15);
            label3.TabIndex = 2;
            label3.Text = "Choose Number Of Ticket";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 149);
            label2.Name = "label2";
            label2.Size = new Size(138, 15);
            label2.TabIndex = 1;
            label2.Text = "Date and Departure Time";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 21);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 0;
            label1.Text = "Choose Area";
            // 
            // grp1
            // 
            grp1.Controls.Add(pb1);
            grp1.Location = new Point(12, 12);
            grp1.Name = "grp1";
            grp1.Size = new Size(571, 407);
            grp1.TabIndex = 2;
            grp1.TabStop = false;
            grp1.Text = "Display Screen";
            // 
            // pb1
            // 
            pb1.Image = (Image)resources.GetObject("pb1.Image");
            pb1.Location = new Point(8, 22);
            pb1.Name = "pb1";
            pb1.Size = new Size(557, 376);
            pb1.SizeMode = PictureBoxSizeMode.StretchImage;
            pb1.TabIndex = 1;
            pb1.TabStop = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(887, 450);
            Controls.Add(grp2);
            Controls.Add(grp1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form2";
            Text = "Ticket Vendor Machine";
            Load += Form2_Load;
            grp2.ResumeLayout(false);
            grp2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numBox).EndInit();
            grp1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pb1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox grp2;
        private GroupBox grp1;
        private PictureBox pb1;
        private Label label1;
        private NumericUpDown numBox;
        private DateTimePicker dtp;
        private ComboBox cbTime;
        private ComboBox cbSC;
        private ComboBox cbArea;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label5;
        private Button btMP;
        private Button btCD;
    }
}