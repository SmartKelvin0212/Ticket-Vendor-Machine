
create database TicketVendorMachine
use TicketVendorMachine

CREATE TABLE area (
    areaId Varchar(30) PRIMARY KEY,
    areaName Varchar(30)
);

CREATE TABLE destinations (
    id Varchar(30) PRIMARY KEY,
    desName Varchar(30),
	areaId Varchar(30),
	FOREIGN KEY (areaId) REFERENCES area(areaId)
);

CREATE TABLE payment_methods (
    id INTEGER PRIMARY KEY,
    name TEXT
);

CREATE TABLE tickets (
    id INTEGER PRIMARY KEY,
    userID INTEGER,
    destination_id Varchar(30),
    payment_method_id INTEGER,
	departure_time time,
	departure_date time,
    price INT,
    purchase_date DATE,
    FOREIGN KEY (destination_id) REFERENCES destinations (id),
    FOREIGN KEY (payment_method_id) REFERENCES payment_methods (id)
);
